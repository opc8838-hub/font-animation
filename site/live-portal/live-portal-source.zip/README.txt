Live Portal source (CellMotion).

The footage is NOT included in this zip (too large). It lives in site/live-portal/assets on GitHub:
https://github.com/opc8838-hub/font-animation/tree/main/site/live-portal/assets

Put that assets/ folder next to index.html, then serve the folder with any static server (python -m http.server) and open index.html?scheme=a or ?scheme=b.

tools/ are reference scripts from the original pipeline; they contain local Windows paths.
