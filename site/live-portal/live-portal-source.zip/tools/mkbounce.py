# 街景「弹跳」循环：稳定 + 0.5× 慢放之后，正放到底再倒放回来(Live Photo 的 Bounce)，两头用余弦缓动减速到 0 再反向
#  base：整段慢放 0..118；full：稳定段 60..118(ext 对得上的后半段)，同样弹跳。
#  meta.bounce 存每个视频帧对应的「慢放帧位置」pb / pf，JS 用它在卡片版和全屏版之间按位置+方向对齐切换。
import cv2, json, subprocess, sys
import numpy as np
sys.path.insert(0, 'work4')
from mkloop2 import FF
E = 11          # 缓动帧数(约 0.37s)
SRC = 'work5/street_stab_slow.mp4'

cap = cv2.VideoCapture(SRC); n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); W = int(cap.get(3)); Hh = int(cap.get(4))
mm = np.memmap('work5/_slow.u8', dtype=np.uint8, mode='w+', shape=(n, Hh, W, 3))
for i in range(n):
    ok, f = cap.read(); mm[i] = f
mm.flush(); print('frames', n)
m = json.load(open('work5/street_stab_meta.json'))
cam60 = np.array(m['cam'], float); gain60 = np.array(m['cam_gain'], float)
xs60 = np.linspace(0, n - 1, len(cam60))
cam = np.array([[np.interp(i, xs60, cam60[:, j]) for j in range(6)] for i in range(n)])
gain = np.array([[np.interp(i, xs60, gain60[:, j]) for j in range(3)] for i in range(n)])


def profile(L):
    """位置序列：正向 0→L 再反向 L→0，每个方向头尾 E 帧余弦缓动。每方向 L+E 帧，中间速度 1 帧/帧"""
    Nd = L + E
    def vel(t):                       # t in [0,Nd)
        if t < E: return 0.5 * (1 - np.cos(np.pi * (t + 0.5) / E))
        if t > Nd - E: return 0.5 * (1 - np.cos(np.pi * (Nd - t - 0.5) / E))
        return 1.0
    v = np.array([vel(t) for t in range(Nd)]); v *= L / v.sum()
    fwd = np.concatenate([[0], np.cumsum(v)])[:-1] if False else np.concatenate([[0], np.cumsum(v)[:-1]])
    bwd = L - fwd
    return np.concatenate([fwd, bwd])


def sample(x):
    i = int(np.floor(x)); i = min(max(i, 0), n - 2); f = x - i
    return i, f


def build(lo, hi, name, vfps=30):
    L = hi - lo
    pos = profile(L) + lo
    p = subprocess.Popen([FF, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', f'{W}x{Hh}', '-r', str(vfps), '-i', '-', '-an', '-c:v', 'libx264', '-crf', '16',
                          '-preset', 'medium', '-g', '12', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', f'assets2/street/{name}'], stdin=subprocess.PIPE)
    co = []; go = []
    for x in pos:
        i, f = sample(x)
        fr = cv2.addWeighted(mm[i], 1 - f, mm[i + 1], f, 0) if f > 1e-3 else mm[i]
        p.stdin.write(np.ascontiguousarray(fr).tobytes())
        co.append(list(map(float, cam[i] * (1 - f) + cam[i + 1] * f))); go.append(list(map(float, gain[i] * (1 - f) + gain[i + 1] * f)))
    p.stdin.close(); p.wait()
    return pos, co, go


posB, cB, gB = build(0, n - 1, 'live.mp4')
posF, cF, gF = build(60, n - 1, 'live_full.mp4')
meta = json.load(open('assets2/street/meta_slow.json'))
meta['cam'] = cB; meta['cam_gain'] = gB; meta['fps'] = 30.0
meta['bounce'] = {'ease': E, 'pb': [round(float(x), 3) for x in posB], 'pf': [round(float(x), 3) for x in posF]}
meta['full'] = {'file': 'live_full.mp4', 'a': 0, 'lo': 0, 'hi': 0, 'len': len(posF), 'cam': cF, 'gain': gF}
meta.pop('loop', None)
json.dump(meta, open('assets2/street/meta.json', 'w'), indent=1)
print('base frames', len(posB), 'full frames', len(posF), 'base period %.1fs' % (len(posB) / 30), 'full period %.1fs' % (len(posF) / 30))
