"""usage: python prep_outro.py [src_dir=phone] [out=web2/outro]
Takes final_rgba.png + final.json (screen corners etc.) from src_dir and writes web2/outro/photo.png (3000 wide, lanczos) + config.json.
Mask is derived at runtime from the alpha inside the screen rect (alpha = 1 - screen coverage), so final_screen_mask.png is not needed by the page.
Also applies the 1px stray-line fix (x=1673, rows 2130-2240 of the 4400 canvas) only if --fixtick is given (phone render artifact)."""
import sys, json, os, numpy as np
from PIL import Image
src=sys.argv[1] if len(sys.argv)>1 and not sys.argv[1].startswith('--') else r'E:\claude工作区\jd-portal\phone'
out=r'E:\claude工作区\jd-portal\web2\outro'
im=Image.open(os.path.join(src,'final_rgba.png')).convert('RGBA')
sj=json.load(open(os.path.join(src,'final.json')))
cw,ch=sj['canvas']; assert im.size==(cw,ch),(im.size,cw,ch)
a=np.array(im)
if '--fixtick' in sys.argv:
    for y in range(2130,2240): a[y,1673]=((a[y,1672].astype(int)+a[y,1674].astype(int))//2).astype('uint8')
# premultiply-safe resize: resize premultiplied then un-premultiply
f=a.astype(np.float32); al=f[...,3:4]/255; pm=np.dstack([f[...,:3]*al,f[...,3:4]])
t=Image.fromarray(pm.astype('uint8'),'RGBA') if False else None
TW=3000; TH=round(ch*TW/cw)
chs=[Image.fromarray(np.clip(pm[...,i],0,255).astype('uint8')).resize((TW,TH),Image.LANCZOS) for i in range(4)]
r=np.dstack([np.array(c) for c in chs]).astype(np.float32); aa=r[...,3:4]/255
rgb=np.where(aa>0.002,r[...,:3]/np.maximum(aa,0.002),0)
res=np.dstack([np.clip(rgb,0,255),r[...,3:4]]).astype('uint8')
Image.fromarray(res,'RGBA').save(os.path.join(out,'photo.png'),optimize=True)
sc=sj['screen_corners_px']; x0,y0=sc['tl']; w,h=sj['screen_size']
cfg={"photo":"photo.png","canvas":[cw,ch],"screen":{"x":x0,"y":y0,"w":w,"h":h},"corner_radius":sj.get('corner_radius_px',135),"crease":False,"bottom_shift":sj.get("bottom_shift_px",0),"bg":[0xDC,0xDF,0xE3]}
json.dump(cfg,open(os.path.join(out,'config.json'),'w'),indent=1)
print(cfg,res.shape)
