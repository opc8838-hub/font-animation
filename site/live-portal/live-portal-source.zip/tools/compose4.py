import json, os, subprocess, shutil
os.chdir(r'E:\claude工作区\jd-portal\out\frames_v4')
M=json.load(open('meta.json')); L=M['log']; fr=M['frames']
i0=next(i for i,(t,f) in enumerate(fr) if t>=L['intro_wall']-0.05)
keep=[(t,f) for t,f in fr[i0:] if not (L['gap_start']+0.3<=t<=L['gap_end'])]
t0=keep[0][0]
print('hitches>70ms',[(round(b[0]-t0,2),round((b[0]-a[0])*1000)) for a,b in zip(keep,keep[1:]) if b[0]-a[0]>0.07 and not (b[0]-a[0]>5)])
with open('list.txt','w') as f:
    for k,(t,fn) in enumerate(keep):
        dur=(keep[k+1][0]-t) if k+1<len(keep) else 0.05
        f.write(f"file '{os.path.basename(fn)}'\nduration {min(dur,0.12):.5f}\n")
    f.write(f"file '{os.path.basename(keep[-1][1])}'\n")
FF='ffmpeg'
r=subprocess.run([FF,'-y','-v','error','-f','concat','-safe','0','-i','list.txt','-vf','fps=30,scale=1920:1080:flags=lanczos,format=yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:v','libx264','-crf','16','-preset','medium','-movflags','+faststart','demo_v3.mp4']); print(r.returncode)
r=subprocess.run([FF,'-y','-v','error','-i','demo_v3.mp4','-vf','scale=1280:-2:flags=lanczos','-c:v','libx264','-crf','24','-preset','medium','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart','demo_v3_wx.mp4']); print(r.returncode)
subprocess.run([FF,'-y','-v','error','-i','demo_v3.mp4','-vf','fps=1/1.5,scale=480:-1,tile=6x4','-frames:v','1',r'..\..\review\demo_v3_sheet.jpg'])
D=r'E:\360MoveData\Users\Administrator\Desktop\新动效\成片'
shutil.copy('demo_v3.mp4',D+r'\立体世界卡片_方案A_演示_v2.mp4'); shutil.copy('demo_v3_wx.mp4',D+r'\立体世界卡片_方案A_演示_v2_发微信用.mp4'); print('copied')
