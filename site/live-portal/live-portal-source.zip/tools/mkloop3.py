# 循环点：背景配准 + 光流补帧(代替叠化)
#  输出顺序 = [补帧 I1..In] + [开头 K 帧(配准变形，量逐帧衰减到 0)] + [源帧 s+K..e]
#  补帧：A=结尾最后一帧(源帧 e)，B=开头第 0 帧(配准到 A 的背景)；DIS 光流，A/B 各向中间位置回拉后按 α 混合，
#  RGB 与深度两半幅用同一套流 → 人物从 A 位置平滑移到 B 位置，不是两个半透明人叠在一起
import sys, json, subprocess
import numpy as np, cv2
sys.path.insert(0, 'work4')
from mkloop2 import gray, register, grid_rms, pick_pair, lerpM, cam_through, sm, I23, S2, FF


def flow_pair(A, B, h, scale=0.5):
    gA = gray(A[:h], scale); gB = gray(B[:h], scale)
    dis = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
    fAB = dis.calc(gA, gB, None); fBA = dis.calc(gB, gA, None)
    W = A.shape[1]
    fAB = cv2.resize(fAB, (W, h)) / scale; fBA = cv2.resize(fBA, (W, h)) / scale
    return fAB, fBA


def interp_frame(A, B, fAB, fBA, a, h):
    W = A.shape[1]
    xs, ys = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(h, dtype=np.float32))
    mA = (xs - a * fAB[..., 0]).astype(np.float32), (ys - a * fAB[..., 1]).astype(np.float32)
    mB = (xs - (1 - a) * fBA[..., 0]).astype(np.float32), (ys - (1 - a) * fBA[..., 1]).astype(np.float32)
    out = []
    for half in (slice(0, h), slice(h, 2 * h)):
        IA = cv2.remap(A[half], mA[0], mA[1], cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        IB = cv2.remap(B[half], mB[0], mB[1], cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        out.append(cv2.addWeighted(IA, 1 - a, IB, a, 0))
    return np.vstack(out)


def run(idn, src, meta_src, lo, hi, nI, K, out_video, vfps, minfrac=0.85, force_pair=None, register_bg=True):
    d = f'assets2/{idn}'; m = json.load(open(meta_src))
    cap = cv2.VideoCapture(src); n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); W = int(cap.get(3)); Hh = int(cap.get(4)); h = Hh // 2
    cam = np.array(m['cam'], float); gain = np.array(m['cam_gain'], float)
    if len(cam) != n:
        xs = np.linspace(0, len(cam) - 1, n)
        cam = np.array([[np.interp(x, range(len(cam)), cam[:, j]) for j in range(6)] for x in xs])
        gain = np.array([[np.interp(x, range(len(gain)), gain[:, j]) for j in range(3)] for x in xs])
    G = []
    while True:
        ok, f = cap.read()
        if not ok: break
        G.append(gray(f[:h], 0.25))
    n = len(G); hi = min(hi, n - 1)
    if force_pair: s, e = force_pair
    else:
        score, s, e, res = pick_pair(G, lo, hi, int((hi - lo + 1) * minfrac))
    L = e - s + 1
    need = {}
    cap = cv2.VideoCapture(src); i = 0
    while True:
        ok, f = cap.read()
        if not ok: break
        if s <= i < s + K or i == e: need[i] = f
        if i > e: break
        i += 1
    A = need[e]; head = [need[s + k] for k in range(K)]
    if register_bg:
        r = register(gray(head[0][:h], 0.5), gray(A[:h], 0.5)); M0 = r[0].copy(); M0[:, 2] *= 2
        before = grid_rms(M0, W, h); person_shift = float(np.median(np.linalg.norm(r[3], axis=1))) * 2 if len(r[3]) else 0.0; inl = r[1]
    else:
        M0 = I23.copy(); before = None; person_shift = None; inl = None
    Tk = [lerpM(M0, I23, sm(k / K)) for k in range(K)]

    def warp2(f, T):
        top = cv2.warpAffine(f[:h], T, (W, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        bot = cv2.warpAffine(f[h:], T, (W, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        return np.vstack([top, bot])

    Wh = [warp2(head[k], Tk[k]) for k in range(K)]
    camH = [cam_through(cam[s + k], Tk[k], W, h) for k in range(K)]
    fAB, fBA = flow_pair(A, Wh[0], h)
    p = subprocess.Popen([FF, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', f'{W}x{Hh}', '-r', str(vfps), '-i', '-', '-an',
                          '-c:v', 'libx264', '-crf', '17', '-preset', 'medium', '-g', '12', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', f'{d}/{out_video}'], stdin=subprocess.PIPE)
    co = []; go = []
    for j in range(1, nI + 1):
        a = j / (nI + 1)
        p.stdin.write(interp_frame(A, Wh[0], fAB, fBA, a, h).tobytes())
        co.append(list(np.array(cam[e]) * (1 - a) + np.array(camH[0]) * a)); go.append(list(gain[e] * (1 - a) + gain[s] * a))
    for k in range(K):
        p.stdin.write(Wh[k].tobytes()); co.append(camH[k]); go.append(list(gain[s + k]))
    cap = cv2.VideoCapture(src); cap.set(cv2.CAP_PROP_POS_FRAMES, s + K)
    for i in range(s + K, e + 1):
        ok, f = cap.read(); p.stdin.write(f.tobytes()); co.append(list(cam[i])); go.append(list(gain[i]))
    p.stdin.close(); p.wait()
    hw = Wh[0]; rr = register(gray(hw[:h], 0.5), gray(A[:h], 0.5))
    rep = {'pair(source frames)': (s, e), 'out_len': nI + L, 'interp_frames': nI,
           'bg_misalign_RMS_px_before': None if before is None else round(before, 2),
           'bg_misalign_RMS_px_after': round(grid_rms(rr[0] * S2, W, h), 2) if rr else None,
           'bg_inlier_ratio': None if inl is None else round(float(inl), 2),
           'person_shift_px': None if person_shift is None else round(person_shift, 1)}
    return m, [list(map(float, c)) for c in co], [list(map(float, g)) for g in go], nI + L, (s, e), rep, nI + K


def finish(base, full):
    m, c, g, n, (s, e), rep, guardB = base
    m['cam'] = c; m['cam_gain'] = g; m['loop'] = {'pair': [s, e], 'interp': True, 'guard': guardB}; m.pop('full', None)
    if full:
        m2, c2, g2, n2, (s2, e2), rep2, guardF = full; off = s2 - s
        m['full'] = {'file': 'live_full.mp4', 'a': off, 'lo': max(guardB, guardF + off), 'hi': min(n - 1, off + n2 - 1), 'len': n2, 'cam': c2, 'gain': g2}
    return m


if __name__ == '__main__':
    which = sys.argv[1]; nI = int(sys.argv[2]) if len(sys.argv) > 2 else 5; K = 15
    if which == 'road':
        b = run('road', 'assets2/road/live_orig.mp4', 'assets2/road/meta_orig.json', 0, 65, nI, K, 'live.mp4', 28.74, force_pair=(14, 46)); print('road', b[3], b[5])
        json.dump(finish(b, None), open('assets2/road/meta.json', 'w'), indent=1)
    if which == 'lake':
        b = run('lake', 'assets2/lake/live_orig.mp4', 'assets2/lake/meta_orig.json', 12, 89, nI, K, 'live.mp4', 28.74, force_pair=(30, 73)); print('lake base', b[3], b[5])
        f = run('lake', 'assets2/lake/live_orig.mp4', 'assets2/lake/meta_orig.json', 12, 89, nI, K, 'live_full.mp4', 28.74, force_pair=b[4]); print('lake full', f[3], f[5])
        json.dump(finish(b, f), open('assets2/lake/meta.json', 'w'), indent=1)
    if which == 'street':
        # 街景：整段(含正面走来/转身)首尾姿态差太大，补帧会撕裂；卡片版和全屏版都只循环稳定段里最像的一对(慢放帧 64..94)
        b = run('street', 'assets2/street/live_slow.mp4', 'assets2/street/meta_slow.json', 60, 118, nI, K, 'live.mp4', 30, force_pair=(64, 94)); print('street base', b[3], b[5])
        f = run('street', 'assets2/street/live_slow.mp4', 'assets2/street/meta_slow.json', 60, 118, nI, K, 'live_full.mp4', 30, force_pair=(64, 94)); print('street full', f[3], f[5])
        mm = finish(b, f); mm['fps'] = 30.0
        json.dump(mm, open('assets2/street/meta.json', 'w'), indent=1)
