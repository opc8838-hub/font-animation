"""v2 composite: g3 hands (round2/got/g3.png) + real model phone render -> phone/final_v2/
python final2.py [cand=round2/got/g3.png]"""
import sys, os, json, numpy as np, cv2
from PIL import Image
from scipy import ndimage as ndi
os.chdir(r'E:\claude工作区\jd-portal\phone')
OUT = 'final_v2'; os.makedirs(OUT, exist_ok=True); os.makedirs('work2', exist_ok=True)
cand = sys.argv[1] if len(sys.argv) > 1 else 'round2/got/g3.png'
W, H = 4400, 2750
BOTTOM_SHIFT = 140
g = cv2.imread(cand)[..., ::-1].astype(np.float32)
gh, gw = g.shape[:2]
gm = (g[..., 1] > 200) & (g[..., 0] < 90) & (g[..., 2] < 90)
ys, xs = np.nonzero(gm)
cy0 = (ys.min() + ys.max()) // 2; cx0 = (xs.min() + xs.max()) // 2
r = np.nonzero(gm[cy0])[0]; c = np.nonzero(gm[:, cx0])[0]
gx0, gx1, gy0, gy1 = r.min(), r.max(), c.min(), c.max()
sj0 = json.load(open('screen.json'))
sw, shh = sj0['screen_size']
sx = sw / (gx1 - gx0 + 1); sy = shh / (gy1 - gy0 + 1); s = (sx + sy) / 2
print('g3 green bbox', gx0, gy0, gx1, gy1, 'scale', sx, sy)
gcx = (gx0 + gx1 + 1) / 2; gcy = (gy0 + gy1 + 1) / 2
ox = sj0['crease_x_px'] - s * gcx            # horizontal: screen centre -> screen centre
oy = H - gh * s                               # bottom of g3 = bottom of canvas
M = np.array([[s, 0, ox], [0, s, oy]], np.float32)
up = cv2.warpAffine(g, M, (W, H), flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_REPLICATE)
# extend background above g3 (flat light grey, subtle gradient): column profile of the top rows, smoothed, + grain
top = int(np.ceil(oy)) + 2
prof = up[top:top + 10].mean(0)
prof = cv2.GaussianBlur(prof[None], (0, 0), 60)[0]
ext = np.repeat(prof[None], top, 0)
# match slight vertical gradient measured over the first 300 rows of g3
dgrad = (up[top + 300:top + 340, :300].mean((0, 1)) - up[top:top + 40, :300].mean((0, 1))) / 300.0
ext = ext + (np.arange(top)[::-1, None, None] * -dgrad[None, None, :]) * 0.6
fade = np.clip((np.arange(top) - (top - 30)) / 30.0, 0, 1)[:, None, None]    # blend over last 30 rows
up[:top] = ext * (1 - fade) + up[:top] * fade
# detail sharpen + grain
bl = cv2.GaussianBlur(up, (0, 0), 2.0); up = np.clip(up + 0.4 * (up - bl), 0, 255)
rng = np.random.default_rng(5); up = np.clip(up + rng.normal(0, 1.5, up.shape[:2])[..., None], 0, 255)
Image.fromarray(up.astype('uint8')).save('work2/g3_up.png')
# ---- phone layer (fix stray tick first), shift into the new canvas
ph = np.array(Image.open('phone_green.png')).astype(np.float32)
sm = np.array(Image.open('screen_mask.png')).astype(np.float32) / 255
for y in range(2130, 2240):
    ph[y, 1673] = (ph[y, 1672] + ph[y, 1674]) / 2; sm[y, 1673] = (sm[y, 1672] + sm[y, 1674]) / 2
dy = int(round(oy + s * gcy - (sj0['screen_corners_px']['tl'][1] + shh / 2)))
print('dy', dy)
def shift(a):
    out = np.zeros((H,) + a.shape[1:], a.dtype)
    y0 = max(0, dy); y1 = min(H, a.shape[0] + dy)
    out[y0:y1] = a[y0 - dy:y1 - dy]; return out
ph = shift(ph); sm = shift(sm)
al = ph[..., 3:4] / 255
R, G, B = up[..., 0], up[..., 1], up[..., 2]
skin = (R - B > 18) & (G < R - 3) & (R > 90)
pale = (R - B > 8) & (G < R + 3) & ((R + G + B) > 200) & ~((G > R + 25) & (G > B + 25))
phone_in = cv2.dilate((al[..., 0] > 0.02).astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
outside = al[..., 0] < 0.05
bg = np.array([up[40:200, 40:400, i].mean() for i in range(3)])
handout = outside & (np.abs(up - bg).max(2) > 16) & skin
handout = ndi.binary_opening(handout, iterations=2)
cnd = ndi.binary_opening((skin | pale) & phone_in, iterations=2)
dil = ndi.binary_dilation(handout, iterations=6)
lab, n = ndi.label(cnd | dil)
ids = np.unique(lab[dil & (lab > 0)]); thumb = cnd & np.isin(lab, ids)
thumb = ndi.binary_closing(thumb, structure=np.ones((3, 3)), iterations=14); thumb = ndi.binary_fill_holes(thumb)
thumb = cv2.erode(thumb.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
T = cv2.GaussianBlur(thumb.astype(np.float32), (0, 0), 1.3)
up2 = up.copy(); up2[..., 1] = np.minimum(up2[..., 1], (up2[..., 0] + up2[..., 2]) / 2)   # despill
T3 = T[..., None]
base = up * (1 - al) + ph[..., :3] * al
comp = base * (1 - T3) + up2 * T3
ring = cv2.GaussianBlur(T, (0, 0), 14); sh = np.clip(ring - T, 0, 1) * 0.30 * al[..., 0] * (1 - T)
comp = comp * (1 - sh[..., None])
fsm = np.clip(sm * (1 - T), 0, 1)
Image.fromarray((fsm * 255).astype('uint8')).save(f'{OUT}/final_screen_mask.png')
alpha = 1 - fsm
rgb = np.where(sm[..., None] > 0.003, up2 * T3, comp)
Image.fromarray(np.dstack([np.clip(rgb, 0, 255), alpha * 255]).astype('uint8'), 'RGBA').save(f'{OUT}/final_rgba.png')
Image.fromarray((T * 255).astype('uint8')).save('work2/thumb.png')
Image.fromarray(np.clip(comp, 0, 255).astype('uint8')).save('work2/comp.png')
x0, y0 = sj0['screen_corners_px']['tl']; y0 += dy
by, bx = np.nonzero(ph[..., 3] > 10)
sj = {"canvas": [W, H], "screen_corners_px": {"tl": [x0, y0], "tr": [x0 + sw, y0], "br": [x0 + sw, y0 + shh], "bl": [x0, y0 + shh]},
      "screen_size": [sw, shh], "screen_aspect": sw / shh, "corner_radius_px": 135, "body_bbox": [int(bx.min()), int(by.min()), int(bx.max()) + 1, int(by.max()) + 1],
      "crease": False, "bottom_shift_px": BOTTOM_SHIFT, "source": cand + f" scale {s:.4f}, dy {dy}"}
json.dump(sj, open(f'{OUT}/final.json', 'w'), indent=1)
# preview + check sheet
home = Image.open('home_shot.png').convert('RGB').resize((sw, shh), Image.LANCZOS)
bgc = Image.new('RGBA', (W, H), tuple(int(v) for v in bg) + (255,))
scr = Image.new('RGBA', (W, H), (0, 0, 0, 0)); scr.paste(home.convert('RGBA'), (x0, y0))
st = Image.alpha_composite(Image.alpha_composite(bgc, scr), Image.open(f'{OUT}/final_rgba.png')).convert('RGB')
st.save('work2/preview_full.png'); st.resize((2200, 1375), Image.LANCZOS).save(f'{OUT}/final_preview.jpg', quality=92)
a = np.array(st)
full = Image.fromarray(a).resize((1100, 688), Image.LANCZOS)
Lh = Image.fromarray(a[1400:2750, 300:1500]).resize((900, 1012), Image.LANCZOS)
Rh = Image.fromarray(a[1400:2750, 2900:4100]).resize((900, 1012), Image.LANCZOS)
cv = Image.new('RGB', (1800, 688 + 1012), (255, 255, 255)); cv.paste(full, (350, 0)); cv.paste(Lh, (0, 688)); cv.paste(Rh, (900, 688))
cv.save('../review/hands_v2_check.jpg', quality=92)
