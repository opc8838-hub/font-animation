"""jd-portal v2 素材。真实 Live 画面不拆层：全幅 Live + 逐帧深度 + AI 左右延伸底图。可重跑，分子命令：
  python prep_v2.py stab [id..]     全幅帧 -> 测抖动 -> 防抖(+放大) -> work2/<id>/s/
  python prep_v2.py loop [id..]     找最佳循环段 + 6 帧交叉淡化 -> work2/<id>/loop/ + poster.jpg
  python prep_v2.py depth [id..]    逐帧深度(全局归一化+时间平滑+引导滤波) -> work2/<id>/depth.npy
  python prep_v2.py pack [id..]     上 RGB 下深度 -> assets2/<id>/live.mp4
  python prep_v2.py subject [id..]  rembg 只在海报帧上抠一次，只算位置/深度 -> meta.json
  python prep_v2.py ext [id..]      从 pano.jpg 裁 ext.jpg(+色调匹配) + ext_depth.png + review/v2_ext_<id>.jpg
  python prep_v2.py all [id..]
三张卡 id = road / street / lake。
v3 新增(只开场用，无 ext)：python prep_v2.py extra vegas cloud goldengate glencanyon   (= stab loop depth pack subject；cloud 先跑 work3/cloud/prep_cloud.py)
框的换算：pano 中 plate_px(3:4) == cover == 视频 crop 框 -> 像素比 s = plate_w / crop_w；
全幅画面在 pano 里的框 = plate 左上角 - crop 左上角 * s，大小 = 视频宽高 * s；防抖放大 z 后可见区域取中间 1/z。
"""
import os, sys, json, glob, subprocess
import numpy as np
import cv2
from PIL import Image

ROOT = os.path.dirname(os.path.abspath(__file__))
os.environ['PATH'] += os.pathsep + r'E:\claude工作区\back-to-work-video\tools'

CARDS = {
    'road':   dict(crop=(0, 16, 720, 960),   frames=78),
    'street': dict(crop=(0, 160, 720, 960),  frames=None),
    'lake':   dict(crop=(190, 0, 540, 720),  frames=None),
}
# v3 新增的 4 个「只用于开场」的卡：没有 ext、没有全屏。帧来自 work3/full_<id>/（ffmpeg 从 mov / 海螺视频解出）
#   win_c = 3:4 卡片窗口中心(归一化，画面坐标)；subj = 主体焦点(归一化)，景物类没有人，手工指定
#   cloud 的源是海螺 AI 视频，由 work3/cloud/prep_cloud.py 先做去假感处理后放进 full_cloud/
EXTRA = {
    'vegas':      dict(fps=28.74, vw=1280, vh=720,  win_c=(0.62, 0.5),  subj=(0.60, 0.42), win_w=None),   # 侧脸为主 + 右侧一部分球幕
    'cloud':      dict(fps=24.0,  vw=768,  vh=1024, win_c=(0.5, 0.5),   subj=(0.80, 0.78), win_w=None),   # 红裤子女生在右下
    'goldengate': dict(fps=28.74, vw=720,  vh=1280, win_c=(0.5, 0.5),   subj=(0.4, 0.5),   win_w=None),
    'glencanyon': dict(fps=28.15, vw=720,  vh=1280, win_c=(0.5, 0.46),  subj=(0.5, 0.45),  win_w=None),
}
FADE = 6
FADES = {}
MIN_LOOP_SEC = 1.6
EXT_SIDES = {'street': 1.1}   # street 镜头摇得最凶，ext 要多留
EXT_SIDE = 0.8        # ext 左右各延伸画面宽度的 80%(任务写 60%，加宽是因为播放时 ext 要跟着镜头平移，会吃掉一部分边)
MPADS = {'street': 0.14}
MPAD = 0.08           # ext 上下各多出画面高度的 8%，给「ext 跟着镜头平移」留余量
WIN_MARGIN = 0.03      # 卡片窗口四边留的余量(占画面宽/高)


def P(*a):
    return os.path.join(ROOT, *a)


def W2(c, *a):
    d = P('work2', c)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, *a) if a else d


def A2(c, *a):
    d = P('assets2', c)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, *a) if a else d


def ids(args):
    return args or list(CARDS)


def info(c):
    if c in EXTRA:
        e = EXTRA[c]
        return dict(fps=e['fps'], vw=e['vw'], vh=e['vh'])
    return json.load(open(P('work', c, 'info.json')))


def meta_load(c):
    p = A2(c, 'meta.json')
    return json.load(open(p)) if os.path.exists(p) else {}


def meta_save(c, **kw):
    m = meta_load(c)
    m.update(kw)
    json.dump(m, open(A2(c, 'meta.json'), 'w'), indent=1, ensure_ascii=False)


def read_rgb(path):
    return np.array(Image.open(path).convert('RGB'))


def load_full(c):
    files = sorted(glob.glob(P('work3', 'full_' + c, 'f*.png') if c in EXTRA else P('work', c, 'full', 'f*.png')))
    n = None if c in EXTRA else CARDS[c]['frames']
    if n:
        files = files[:n]
    return [read_rgb(f) for f in files]


# ---------------------------------------------------------------- stab
def pair_M(ga, gb):
    """ga -> gb 的相似变换(3x3)，RANSAC 把人物当外点剔除"""
    p0 = cv2.goodFeaturesToTrack(ga, 1500, 0.01, 8, blockSize=7)
    p1, st, _ = cv2.calcOpticalFlowPyrLK(ga, gb, p0, None, winSize=(31, 31), maxLevel=4)
    p0b, st2, _ = cv2.calcOpticalFlowPyrLK(gb, ga, p1, None, winSize=(31, 31), maxLevel=4)
    ok = (st[:, 0] == 1) & (st2[:, 0] == 1) & (np.linalg.norm(p0b - p0, axis=2)[:, 0] < 0.6)
    M, mask = cv2.estimateAffinePartial2D(p0[ok], p1[ok], method=cv2.RANSAC, ransacReprojThreshold=1.0, maxIters=4000, confidence=0.999)
    return np.vstack([M, [0, 0, 1]]), int(mask.sum())


def pair_A(ga, gb):
    """同 pair_M，但用完整仿射(6 自由度)，给 cam 的链式跟踪用"""
    p0 = cv2.goodFeaturesToTrack(ga, 2000, 0.005, 6, blockSize=7)
    p1, st, _ = cv2.calcOpticalFlowPyrLK(ga, gb, p0, None, winSize=(31, 31), maxLevel=4)
    p0b, st2, _ = cv2.calcOpticalFlowPyrLK(gb, ga, p1, None, winSize=(31, 31), maxLevel=4)
    ok = (st[:, 0] == 1) & (st2[:, 0] == 1) & (np.linalg.norm(p0b - p0, axis=2)[:, 0] < 0.6)
    M, mask = cv2.estimateAffine2D(p0[ok], p1[ok], method=cv2.RANSAC, ransacReprojThreshold=1.2, maxIters=5000, confidence=0.999)
    return np.vstack([M, [0, 0, 1]]), int(mask.sum())


def estimate_tracks(frames):
    """链式跟踪：C[t] = 第 1 帧坐标 -> 第 t 帧坐标"""
    gs = [cv2.cvtColor(f, cv2.COLOR_RGB2GRAY) for f in frames]
    C = [np.eye(3)]
    inl = [0]
    for t in range(1, len(gs)):
        M, n = pair_M(gs[t - 1], gs[t])
        C.append(M @ C[-1])
        inl.append(n)
    return C, inl


def params(M):
    a, b, tx = M[0]
    c, d, ty = M[1]
    return np.array([tx, ty, np.arctan2(c, a), np.hypot(a, c)])


def from_params(p):
    tx, ty, r, s = p
    return np.array([[s * np.cos(r), -s * np.sin(r), tx], [s * np.sin(r), s * np.cos(r), ty], [0, 0, 1]])


def lowpass(par, sigma=6):
    from scipy.ndimage import gaussian_filter1d
    k = int(sigma * 4)
    pad = np.concatenate([2 * par[:1] - par[1:k + 1][::-1], par, 2 * par[-1:] - par[-k - 1:-1][::-1]])   # 奇对称延拓，不让趋势在两端偏
    return gaussian_filter1d(pad, sigma, axis=0)[k:-k]


def cmd_stab(args):
    from scipy.ndimage import gaussian_filter1d
    for c in ids(args):
        frames = load_full(c)
        h, w = frames[0].shape[:2]
        C, inl = estimate_tracks(frames)
        par = np.array([params(M) for M in C])
        sig = 12 if c == 'street' else 6
        low = lowpass(par, sig)
        res = par - low
        if c == 'street':      # 手持晃动幅度远超 4% 放大能吃下的范围：夹住修正量，只做吃得下的那部分
            zc = 1.04
            mxy = np.array([(zc - 1) / 2 * w, (zc - 1) / 2 * h]) * 0.85
            res[:, :2] = np.clip(res[:, :2], -mxy, mxy)
            low = par - res
        R = max(w, h) / 2
        jit = np.hypot(res[:, 0], res[:, 1]) + np.abs(res[:, 2]) * R + np.abs(res[:, 3] - 1 + (1 - low[:, 3])) * R
        print(f'{c}: {len(frames)} 帧 {w}x{h}  相机总位移(平移) {np.hypot(par[:,0],par[:,1]).max():.1f}px  '
              f'高频抖动(相对 σ=6 帧低通) 最大 {np.hypot(res[:,0],res[:,1]).max():.2f}px 旋转 {np.degrees(np.abs(res[:,2]).max()):.3f}deg  内点 min {min(inl[1:])}')
        os.makedirs(W2(c, 's'), exist_ok=True)
        for f in glob.glob(W2(c, 's', '*.png')):
            os.remove(f)
        worst = float(jit.max())
        np.savez(W2(c, 'traj.npz'), C=np.array(C), par=par, low=low)
        if worst <= 1.0:
            z = 1.0
            out = frames
            print('  抖动 <=1px，不处理（相机整体的平移保留，那是拍摄时的运镜）')
        else:
            corners = np.array([[0, 0, 1], [w, 0, 1], [0, h, 1], [w, h, 1]], np.float64).T
            need = 0
            Rs = []
            for t in range(len(frames)):
                Rt = C[t] @ np.linalg.inv(from_params(low[t]))   # 输出(稳定后)坐标 -> 原帧坐标
                Rs.append(Rt)
                q = (Rt @ corners)[:2]
                dx = max(0, -q[0].min(), q[0].max() - w); dy = max(0, -q[1].min(), q[1].max() - h)
                need = max(need, 2 * dx / w, 2 * dy / h)
            z = float(np.clip(1 + need + 0.003, 1.03, 1.04))
            if 1 + need > 1.04:
                print('  警告：需要放大 %.1f%% 才能盖住黑边，已截到 4%%，边缘用复制填充' % (need * 100))
            print(f'  防抖：只去高频抖动，放大 {z:.4f}')
            Z = np.array([[z, 0, (1 - z) * w / 2], [0, z, (1 - z) * h / 2], [0, 0, 1]])
            out = []
            for fr, Rt in zip(frames, Rs):
                Tm = Rt @ np.linalg.inv(Z)
                out.append(cv2.warpAffine(fr, Tm[:2], (w, h), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE))
            C2, _ = estimate_tracks(out)
            p2 = np.array([params(M) for M in C2])
            r2 = p2 - lowpass(p2, sig)
            print(f'  防抖后残余高频抖动 max {np.hypot(r2[:,0],r2[:,1]).max():.2f}px')
        for i, fr in enumerate(out):
            Image.fromarray(fr).save(W2(c, 's', 'f%04d.png' % (i + 1)))
        meta_save(c, zoom=float(z), stab_worst_px=worst, src_frames=len(out), camera_pan_px=float(np.hypot(par[:,0],par[:,1]).max()))


# ---------------------------------------------------------------- loop
LOOPCFG = {'road': dict(min_sec=2.2), 'street': dict(full=True), 'lake': dict(min_sec=2.5),
           'vegas': dict(full=True), 'cloud': dict(full=True), 'goldengate': dict(full=True), 'glencanyon': dict(full=True)}


def cmd_loop(args):
    """硬切循环(原生 Live 的做法)：不做交叉淡化，不对齐尾帧。找首尾最像的一对帧，循环段尽量长，且必须包含 cover 对应的参考帧。"""
    for c in ids(args):
        inf = info(c)
        fps = inf['fps']
        files = sorted(glob.glob(W2(c, 's', 'f*.png')))
        fr = [read_rgb(f) for f in files]
        L = len(fr)
        cfg = LOOPCFG[c]
        ref_i = (L // 2) if c in EXTRA else json.load(open(P('work', c, 'map.json')))['frame']
        small = [cv2.GaussianBlur(cv2.resize(cv2.cvtColor(f, cv2.COLOR_RGB2GRAY), None, fx=.25, fy=.25, interpolation=cv2.INTER_AREA), (0, 0), 1).astype(np.float32) for f in fr]
        minlen = L if cfg.get('full') else int(np.ceil(cfg['min_sec'] * fps))
        cands = []
        for i in range(0, L - minlen + 1):
            for j in range(i + minlen, L + 1):
                if not (i <= ref_i < j):
                    continue
                cands.append((float(np.abs(small[j - 1] - small[i]).mean()), i, j))
        cands.sort()
        best = cands[0][0]
        pool = [x for x in cands if x[0] <= best * 1.08]
        d, i, j = max(pool, key=lambda x: x[2] - x[1])
        N = j - i
        adj = np.mean([np.abs(small[k + 1] - small[k]).mean() for k in range(i, j - 1)])
        print(f'{c}: {L} 帧 fps {fps}  循环段 [{i},{j}) 共 {N} 帧 = {N/fps:.2f}s  硬切  接点差 {d:.2f} (段内相邻帧平均差 {adj:.2f})  参考帧 {ref_i} 在段内第 {ref_i-i} 帧')
        out = fr[i:j]
        os.makedirs(W2(c, 'loop'), exist_ok=True)
        for f in glob.glob(W2(c, 'loop', '*.png')):
            os.remove(f)
        for k, o in enumerate(out):
            Image.fromarray(o).save(W2(c, 'loop', 'f%04d.png' % (k + 1)))
        pidx = ref_i - i
        Image.fromarray(out[pidx]).save(A2(c, 'poster.jpg'), quality=92, subsampling=0)
        h, w = out[0].shape[:2]
        meta_save(c, poster_idx=pidx, fade=0, hard_cut=True, w=w, h=h, fps=fps, frames=len(out), loop_src=[i, j], loop_wrap_diff=float(d), loop_adj_diff=float(adj))


# ---------------------------------------------------------------- depth
_model = None


def get_model():
    global _model
    if _model is None:
        import torch
        from transformers import AutoImageProcessor, AutoModelForDepthEstimation
        name = 'depth-anything/Depth-Anything-V2-Small-hf'
        _model = (AutoImageProcessor.from_pretrained(name), AutoModelForDepthEstimation.from_pretrained(name).eval())
    return _model


def raw_depth(img):
    """img: HxWx3 uint8 -> HxW float32 原始深度(近处大)"""
    import torch
    proc, model = get_model()
    inp = proc(images=Image.fromarray(img), return_tensors='pt')
    with torch.no_grad():
        d = model(**inp).predicted_depth
    d = torch.nn.functional.interpolate(d[None], size=img.shape[:2], mode='bicubic', align_corners=False)[0, 0].numpy()
    return d.astype(np.float32)


def guided(p, I, r=6, eps=1e-3):
    """引导滤波：p 深度 [0,1]，I 灰度引导 [0,1]。保住人物边缘。"""
    k = (2 * r + 1, 2 * r + 1)
    mI = cv2.boxFilter(I, -1, k); mp = cv2.boxFilter(p, -1, k)
    cov = cv2.boxFilter(I * p, -1, k) - mI * mp
    var = cv2.boxFilter(I * I, -1, k) - mI * mI
    a = cov / (var + eps); b = mp - a * mI
    return cv2.boxFilter(a, -1, k) * I + cv2.boxFilter(b, -1, k)


def cmd_depth(args):
    for c in ids(args):
        files = sorted(glob.glob(W2(c, 'loop', 'f*.png')))
        fr = [read_rgb(f) for f in files]
        raws = []
        for k, f in enumerate(fr):
            raws.append(raw_depth(f))
            if k % 20 == 0:
                print(c, 'depth', k, '/', len(fr), flush=True)
        R = np.stack(raws)
        lo, hi = np.percentile(R, 1), np.percentile(R, 99)       # 全段统一归一化
        D = np.clip((R - lo) / (hi - lo + 1e-9), 0, 1)
        # 时间平滑：前后各 2 帧，循环环绕
        wts = np.array([1, 2, 3, 2, 1], np.float32); wts /= wts.sum()
        N = len(D)
        S = np.zeros_like(D)
        for o, wt in zip(range(-2, 3), wts):
            S += wt * D[np.clip(np.arange(N) + o, 0, N - 1)]
        # 空间：引导滤波(RGB 亮度作引导，保边)
        out = np.zeros_like(S)
        for k in range(N):
            g = cv2.cvtColor(fr[k], cv2.COLOR_RGB2GRAY).astype(np.float32) / 255
            out[k] = np.clip(guided(S[k], g), 0, 1)
        np.save(W2(c, 'depth.npy'), out.astype(np.float16))
        meta_save(c, depth_lo=float(lo), depth_hi=float(hi))
        print(c, 'depth done', out.shape, 'range', float(out.min()), float(out.max()))


# ---------------------------------------------------------------- pack
def cmd_pack(args):
    for c in ids(args):
        files = sorted(glob.glob(W2(c, 'loop', 'f*.png')))
        D = np.load(W2(c, 'depth.npy')).astype(np.float32)
        h, w = read_rgb(files[0]).shape[:2]
        assert w % 2 == 0 and h % 2 == 0
        fps = meta_load(c)['fps']
        cmd = ['ffmpeg', '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{w}x{2*h}', '-r', str(fps), '-i', '-',
               '-vf', 'scale=out_color_matrix=bt709:out_range=tv:flags=accurate_rnd+full_chroma_int,format=yuv420p',
               '-c:v', 'libx264', '-crf', '18', '-preset', 'slow', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
               '-movflags', '+faststart', '-an', A2(c, 'live.mp4')]
        pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        for f, d in zip(files, D):
            rgb = read_rgb(f)
            g = np.clip(d * 255 + .5, 0, 255).astype(np.uint8)
            frame = np.concatenate([rgb, np.repeat(g[:, :, None], 3, 2)], 0)
            pr.stdin.write(frame.tobytes())
        pr.stdin.close(); pr.wait()
        print(c, 'live.mp4', f'{w}x{2*h}', os.path.getsize(A2(c, 'live.mp4')) // 1024, 'KB')
        meta_save(c, packed=[w, 2 * h])


# ---------------------------------------------------------------- subject
def largest_cc(m):
    n, lab, st, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
    if n <= 1:
        return m
    k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
    return lab == k


def cmd_subject(args):
    from rembg import new_session, remove
    sess = new_session('isnet-general-use')
    for c in ids(args):
        m = meta_load(c)
        w, h = m['w'], m['h']
        poster = read_rgb(A2(c, 'poster.jpg'))
        a = np.array(remove(Image.fromarray(poster), session=sess, only_mask=True)).astype(np.float32) / 255
        mask = largest_cc(a > .5)
        if c in EXTRA:        # 开场卡：rembg 会抠到球幕/景物，统一用手工焦点，深度取焦点附近
            sx, sy = EXTRA[c]['subj']
            mask = np.zeros((h, w), bool); mask[int(sy * h) - 20:int(sy * h) + 20, int(sx * w) - 20:int(sx * w) + 20] = True
        ys, xs = np.where(mask)
        bx0, bx1, by0, by1 = xs.min() / w, (xs.max() + 1) / w, ys.min() / h, (ys.max() + 1) / h
        D0 = np.load(W2(c, 'depth.npy'))[meta_load(c)['poster_idx']].astype(np.float32)
        dsub = float(D0[mask].mean())
        cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
        Image.fromarray((mask * 255).astype(np.uint8)).save(W2(c, 'subject_mask.png'))
        # 卡片窗口：v1 crop 中心换到防抖放大后的坐标，3:4，四边留 3% 余量
        z = m['zoom']
        mx, my = WIN_MARGIN * w, WIN_MARGIN * h
        if c in EXTRA:
            ccx, ccy = EXTRA[c]['win_c'][0] * w, EXTRA[c]['win_c'][1] * h
        else:
            x, y, cw, ch = CARDS[c]['crop']
            src_w, src_h = info(c)['vw'], info(c)['vh']
            ccx = ((x + cw / 2) - src_w / 2) * z + w / 2
            ccy = ((y + ch / 2) - src_h / 2) * z + h / 2
        ww = min(w - 2 * mx, (h - 2 * my) * 3 / 4)
        wh = ww * 4 / 3
        wx0 = float(np.clip(ccx - ww / 2, mx, w - mx - ww))
        wy0 = float(np.clip(ccy - wh / 2, my, h - my - wh))
        win = [wx0 / w, wy0 / h, (wx0 + ww) / w, (wy0 + wh) / h]
        meta_save(c, subject=dict(bbox=[bx0, by0, bx1, by1], center=[cx, cy], depth=dsub, mask_area=float(mask.mean())),
                  card_window=win, card_window_px=[wx0, wy0, ww, wh])
        print(c, 'subject bbox', [round(v, 3) for v in (bx0, by0, bx1, by1)], 'depth', round(dsub, 3), 'window', [round(v, 3) for v in win])


# ---------------------------------------------------------------- ext
def frame_box_in_pano(c):
    """视频(防抖放大后)可见区域在 pano 里的框 (x0,y0,w,h)，及 pano 像素/视频像素 比"""
    pj = json.load(open(P('assets', c, 'pano.json')))
    px0, py0, px1, py1 = pj['plate_px']
    x, y, cw, ch = CARDS[c]['crop']
    s = ((px1 - px0) / cw + (py1 - py0) / ch) / 2
    inf = info(c)
    vw, vh = inf['vw'], inf['vh']
    fx0 = px0 - x * s
    fy0 = py0 - y * s
    z = meta_load(c)['zoom']
    Wf, Hf = vw * s, vh * s
    return fx0 + Wf * (1 - 1 / z) / 2, fy0 + Hf * (1 - 1 / z) / 2, Wf / z, Hf / z, s / z


def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def build_ext(c, Mtot=None):
    """从 pano 一次重采样得到 ext：ext'(P) = ext(Mtot P)，ext 的坐标 (u,v) <-> pano (ex0 + u*r, vy0 + v*r)。
    Mtot 把「海报对位」折进去，避免先裁再 warp 出现边缘复制拖影。竖直方向 pano 不够的地方：边缘行向外延伸，再逐渐换成大半径模糊。"""
    m = meta_load(c)
    w, h = m['w'], m['h']
    pano = read_rgb(P('assets', c, 'pano.jpg'))
    H, Wp = pano.shape[:2]
    vx0, vy0, Wv, Hv, r = frame_box_in_pano(c)        # r = pano px / 视频 px
    ew = int(round(w * (1 + 2 * EXT_SIDES.get(c, EXT_SIDE))))
    oy = int(round(h * MPADS.get(c, MPAD))); eh = h + 2 * oy
    ex0 = vx0 - EXT_SIDES.get(c, EXT_SIDE) * Wv
    PAD = 700
    pp = cv2.copyMakeBorder(pano, PAD, PAD, 0, 0, cv2.BORDER_REPLICATE)
    bl = cv2.GaussianBlur(pp, (0, 0), 45)
    wy = np.ones(pp.shape[0], np.float32)
    wy[:PAD] = 0; wy[PAD:PAD + 120] = np.linspace(0, 1, 120) ** 1.5
    wy[-PAD:] = 0; wy[-PAD - 120:-PAD] = np.linspace(1, 0, 120) ** 1.5
    pp = np.clip(pp.astype(np.float32) * wy[:, None, None] + bl.astype(np.float32) * (1 - wy[:, None, None]), 0, 255).astype(np.uint8)
    ps = cv2.resize(pp, (int(round(pp.shape[1] / r)), int(round(pp.shape[0] / r))), interpolation=cv2.INTER_AREA)
    rx, ry = ps.shape[1] / pp.shape[1], ps.shape[0] / pp.shape[0]
    T = np.array([[1, 0, ex0 * rx], [0, 1, (vy0 + PAD) * ry - oy], [0, 0, 1]], np.float64)
    Fm = T @ (np.eye(3) if Mtot is None else Mtot)
    ext = cv2.warpAffine(ps, Fm[:2], (ew, eh), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE)
    corners = np.array([[0, 0, 1], [ew, 0, 1], [0, eh, 1], [ew, eh, 1]]).T
    q = (Fm @ corners)[:2] / np.array([[rx], [ry]])      # 在 pad 后 pano 像素里的范围
    out_x = float(max(0, -q[0].min(), q[0].max() - Wp)); out_y = float(max(0, -(q[1].min() - PAD), (q[1].max() - PAD) - H))
    rect = [EXT_SIDES.get(c, EXT_SIDE) * w / ew, oy / eh, (1 + EXT_SIDES.get(c, EXT_SIDE)) * w / ew, (oy + h) / eh]            # 视频在 ext 里的矩形(归一化)
    return ext, rect, dict(pad_t=0, pad_b=0, r=float(r), pano_overflow_x=out_x, pano_overflow_y=out_y)


def register(poster, ext, ox, full=False):
    """poster 左右边带(避开人物) 与整张 ext 做 SIFT 匹配 -> 相似变换 M(poster 点 -> ext 点)；返回 (Mtot 3x3, 内点数, 残差)"""
    h, w = poster.shape[:2]
    sift = cv2.SIFT_create(4000)
    mask = np.zeros((h, w), np.uint8); mask[:, :int(w * .3)] = 255; mask[:, int(w * .7):] = 255
    if full:
        mask[:] = 255
    g1 = cv2.cvtColor(poster, cv2.COLOR_RGB2GRAY); g2 = cv2.cvtColor(ext, cv2.COLOR_RGB2GRAY)
    k1, d1 = sift.detectAndCompute(g1, mask)
    m2 = np.zeros(g2.shape, np.uint8); m2[:, max(0, ox - (500 if full else 60)):ox + w + (500 if full else 60)] = 255
    k2, d2 = sift.detectAndCompute(g2, m2)
    ms = cv2.BFMatcher().knnMatch(d1, d2, k=2)
    good = [m for m, n in ms if m.distance < (0.82 if full else 0.75) * n.distance]
    p1 = np.float32([k1[m.queryIdx].pt for m in good]); p2 = np.float32([k2[m.trainIdx].pt for m in good])
    M, inl = cv2.estimateAffinePartial2D(p1, p2, method=cv2.RANSAC, ransacReprojThreshold=2.0, maxIters=5000)
    M = np.vstack([M, [0, 0, 1]])
    res = np.linalg.norm((p1[inl[:, 0] == 1] @ M[:2, :2].T + M[:2, 2]) - p2[inl[:, 0] == 1], axis=1).mean()
    return M, int(inl.sum()), float(res)


def band_gain(vid, ext_in, side, band=40):
    """视频在 ext 里的边带(40px)逐行比较，返回 (h,3) 增益，排除人物/差异大的像素"""
    h, w = vid.shape[:2]
    sl = slice(0, band) if side == 'L' else slice(w - band, w)
    a = vid[:, sl].astype(np.float32); b = ext_in[:, sl].astype(np.float32)
    la = a.mean(2); lb = b.mean(2)
    ok = (np.abs(la - lb) < 40).astype(np.float32)[:, :, None]
    num = (a * ok).sum(1); den = (b * ok).sum(1); cnt = ok.sum(1)
    ga = np.where(cnt > 5, (num + 1) / (den + 1), np.nan)
    # 缺失行插值
    for ch in range(3):
        col = ga[:, ch]; idx = np.where(~np.isnan(col))[0]
        col[np.isnan(col)] = np.interp(np.where(np.isnan(col))[0], idx, col[idx]) if len(idx) else 1.0
    ga = cv2.GaussianBlur(ga.astype(np.float32)[:, None, :], (0, 0), sigmaX=0.1, sigmaY=40)[:, 0, :]
    return np.clip(ga, 0.7, 1.4)


def cmd_ext(args):
    for c in ids(args):
        m = meta_load(c)
        w, h = m['w'], m['h']
        poster = read_rgb(A2(c, 'poster.jpg'))
        # 对位：把 ext 配准到海报帧(相机相对 cover 参考帧有位移/旋转)
        ox = int(round(EXT_SIDES.get(c, EXT_SIDE) * w))
        # 用视频自身的帧做配准(比对 AI 全景稳)：ext 是按 cover 对应的参考帧(map.json 的 frame)裁的，
        # 参考帧 --SIFT/RANSAC--> 海报帧 得 M；ext 内坐标 = Z(p_ref)，Z 是防抖放大；故 海报坐标 -> ext 内坐标 = Z M^-1
        ref_idx = json.load(open(P('work', c, 'map.json')))['frame']
        ref = read_rgb(P('work', c, 'full', 'f%04d.png' % (ref_idx + 1)))
        sift = cv2.SIFT_create(6000)
        gr, gp = cv2.cvtColor(ref, cv2.COLOR_RGB2GRAY), cv2.cvtColor(poster, cv2.COLOR_RGB2GRAY)
        k1, d1 = sift.detectAndCompute(gr, None); k2, d2 = sift.detectAndCompute(gp, None)
        ms = cv2.BFMatcher().knnMatch(d1, d2, k=2)
        good = [m for m, n in ms if m.distance < 0.75 * n.distance]
        p1 = np.float32([k1[m.queryIdx].pt for m in good]); p2 = np.float32([k2[m.trainIdx].pt for m in good])
        Mr, inl = cv2.estimateAffinePartial2D(p1, p2, method=cv2.RANSAC, ransacReprojThreshold=2.0, maxIters=8000)
        Mr = np.vstack([Mr, [0, 0, 1]]); ninl = int(inl.sum())
        z = m['zoom']
        Z = np.array([[z, 0, (1 - z) * w / 2], [0, z, (1 - z) * h / 2], [0, 0, 1]])
        if ninl < 40:     # 帧间差太大(street 手持大幅摇)：改用防抖时链式跟踪的轨迹  ref -> 海报帧 = Z @ low[t] @ C[ref]^-1
            tr = np.load(W2(c, 'traj.npz'))
            t_p = m['loop_src'][0] + m['poster_idx']
            Mr = Z @ from_params(tr['low'][t_p]) @ np.linalg.inv(tr['C'][ref_idx])
            ninl = -1
            print('  SIFT 内点不足，改用链式跟踪轨迹')
        Mq = Z @ np.linalg.inv(Mr)                    # 海报坐标 -> ext 内坐标
        oy = int(round(h * MPADS.get(c, MPAD)))
        Mtot = np.array([[1, 0, ox], [0, 1, oy], [0, 0, 1]]) @ Mq @ np.array([[1, 0, -ox], [0, 1, -oy], [0, 0, 1]])
        ang = np.degrees(np.arctan2(Mr[1, 0], Mr[0, 0])); sc = np.hypot(Mr[0, 0], Mr[1, 0]); M = Mr; res = 0.0
        print(c, f'ext 配准(参考帧 {ref_idx} -> 海报帧): 内点 {ninl}  平移 ({Mr[0,2]:.1f},{Mr[1,2]:.1f}) 旋转 {ang:.2f}deg 缩放 {sc:.4f}')
        ext, rect, bi = build_ext(c, Mtot)
        print('  ext 取样越出 pano：横向 %.0fpx 竖向 %.0fpx(pano 像素，越出部分用延伸+模糊)' % (bi['pano_overflow_x'], bi['pano_overflow_y']))
        M2, n2, r2 = register(poster, ext[oy:oy + h], ox, True)
        print(f'  配准后用全景再测(参考，内点 {n2}): 平移 ({M2[0,2]-ox:.2f},{M2[1,2]:.2f}) 缩放 {np.hypot(M2[0,0],M2[1,0]):.4f} 残差 {r2:.2f}')
        M = np.array([[1, 0, ox + Mr[0, 2]], [0, 1, Mr[1, 2]], [0, 0, 1]])   # 仅供 meta 记录
        dx = dy = 0.0
        ox = int(round(EXT_SIDES.get(c, EXT_SIDE) * w))
        inner = ext[oy:oy + h, ox:ox + w]
        gl = band_gain(poster, inner, 'L'); gr = band_gain(poster, inner, 'R')
        print('  色调增益 左', gl.mean(0).round(3), '右', gr.mean(0).round(3))
        ew = ext.shape[1]
        xs = np.arange(ew, dtype=np.float32)
        t = np.clip((xs - ox) / w, 0, 1)                      # 0 在视频左缘，1 在右缘
        glp = np.pad(gl, ((oy, oy), (0, 0)), mode='edge'); grp = np.pad(gr, ((oy, oy), (0, 0)), mode='edge')
        G = glp[:, None, :] * (1 - t)[None, :, None] + grp[:, None, :] * t[None, :, None]
        ext2 = np.clip(ext.astype(np.float32) * G + .5, 0, 255).astype(np.uint8)
        Image.fromarray(ext2).save(A2(c, 'ext.jpg'), quality=93, subsampling=0)
        # 深度
        De = raw_depth(ext2)
        D0 = np.load(W2(c, 'depth.npy'))[meta_load(c)['poster_idx']].astype(np.float32)
        # 线性拟合到视频深度(边带 40px，排除人物)
        mk = np.array(Image.open(W2(c, 'subject_mask.png')).convert('L')) > 127
        mk = cv2.dilate(mk.astype(np.uint8), np.ones((15, 15))) > 0
        band = np.zeros((h, w), bool); band[:, :80] = True; band[:, -80:] = True
        sel = band & ~mk
        x = De[oy:oy + h, ox:ox + w][sel]; y = D0[sel]
        a, b = np.polyfit(x, y, 1)
        Dn = np.clip(De * a + b, 0, 1)
        corr = np.corrcoef(x, y)[0, 1]
        print(f'  ext 深度 -> 视频深度 线性拟合 a={a:.3f} b={b:.3f} 相关 {corr:.3f}')
        Dn = cv2.GaussianBlur(Dn, (0, 0), 1.2)
        Image.fromarray((Dn * 255 + .5).astype(np.uint8)).save(A2(c, 'ext_depth.png'))
        meta_save(c, ext=dict(w=ew, h=ext.shape[0], video_rect=rect, register=dict(tx=float(Mr[0,2]), ty=float(Mr[1,2]), rot_deg=float(ang), scale=float(sc), inliers=ninl), pad_top=bi['pad_t'], pad_bottom=bi['pad_b'],
                              depth_fit=[float(a), float(b), float(corr)], gain_left=gl.mean(0).tolist(), gain_right=gr.mean(0).tolist()))
        review_ext(c, ext2, poster, rect)


def review_ext(c, ext, poster, rect):
    h, w = poster.shape[:2]
    ew = ext.shape[1]
    ox = int(round(rect[0] * ew)); oy = int(round(rect[1] * ext.shape[0]))
    comp = ext.astype(np.float32).copy()
    f = int(round(0.05 * w))
    m = np.ones(w, np.float32)
    ramp = np.linspace(0, 1, f + 2)[1:-1] ** 1
    ramp = ramp * ramp * (3 - 2 * ramp)
    m[:f] = ramp; m[-f:] = ramp[::-1]
    comp[oy:oy + h, ox:ox + w] = comp[oy:oy + h, ox:ox + w] * (1 - m[None, :, None]) + poster.astype(np.float32) * m[None, :, None]
    comp = np.clip(comp, 0, 255).astype(np.uint8)
    os.makedirs(P('review'), exist_ok=True)
    full = Image.fromarray(comp)
    s = 1400 / ew
    eh = comp.shape[0]
    big = full.resize((1400, int(eh * s)), Image.LANCZOS)
    # 两个接缝放大 2x（以接缝为中心，宽 400 高 full）
    cw_ = 360
    cl = comp[:, max(0, ox - cw_ // 2 + f // 2):ox - cw_ // 2 + f // 2 + cw_]
    cr = comp[:, ox + w - cw_ // 2 - f // 2:ox + w - cw_ // 2 - f // 2 + cw_]
    sc = min(1.0, 1100 / eh) * 1.0
    cl = Image.fromarray(cl).resize((int(cl.shape[1] * 1.5 * sc), int(eh * 1.5 * sc)), Image.LANCZOS)
    cr = Image.fromarray(cr).resize((int(cr.shape[1] * 1.5 * sc), int(eh * 1.5 * sc)), Image.LANCZOS)
    H = big.height + cl.height + 10
    canvas = Image.new('RGB', (1400, H), (30, 30, 30))
    canvas.paste(big, (0, 0))
    canvas.paste(cl, (0, big.height + 10)); canvas.paste(cr, (cl.width + 10, big.height + 10))
    canvas.save(P('review', f'v2_ext_{c}.jpg'), quality=92)
    print('  review ->', P('review', f'v2_ext_{c}.jpg'))


def sim_match(frame, ext_gray, ox, oy, w, h):
    """帧(只用左右 30% 边带，避开人物) -> ext 坐标的相似变换 (3x3)，返回 (A, 内点数)"""
    sift = cv2.SIFT_create(3000)
    g1 = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    mask = np.zeros((h, w), np.uint8); mask[:, :int(w * .3)] = 255; mask[:, int(w * .7):] = 255
    k1, d1 = sift.detectAndCompute(g1, mask)
    m2 = np.zeros(ext_gray.shape, np.uint8)
    m2[max(0, oy - int(h * .06)):oy + h + int(h * .06), max(0, ox - int(w * .5)):ox + w + int(w * .5)] = 255
    k2, d2 = sift.detectAndCompute(ext_gray, m2)
    if d1 is None or d2 is None or len(k1) < 8:
        return None, 0
    ms = cv2.BFMatcher().knnMatch(d1, d2, k=2)
    good = [m for m, n in (x for x in ms if len(x) == 2) if m.distance < 0.78 * n.distance]
    if len(good) < 8:
        return None, 0
    p1 = np.float32([k1[m.queryIdx].pt for m in good]); p2 = np.float32([k2[m.trainIdx].pt for m in good])
    A, inl = cv2.estimateAffine2D(p1, p2, method=cv2.RANSAC, ransacReprojThreshold=2.0, maxIters=6000)   # 完整仿射：允许各向异性缩放/剪切，吃一点透视
    if A is None:
        return None, 0
    return np.vstack([A, [0, 0, 1]]), int(inl.sum())


def cmd_cam(args):
    """每帧 -> 海报(=ext 内)坐标的相似变换(平移+旋转+缩放)。ext 是静态图，播放时按这个变换跟着背景走。
    直接把每帧的左右边带和 ext 配准(ext 视频区域本来就是 cover 的真实像素)，内点不足的帧用相邻帧插值。"""
    from scipy.ndimage import gaussian_filter1d
    for c in ids(args):
        m = meta_load(c)
        w, h = m['w'], m['h']
        files = sorted(glob.glob(W2(c, 'loop', 'f*.png')))
        ext = read_rgb(A2(c, 'ext.jpg'))
        eg = cv2.cvtColor(ext, cv2.COLOR_RGB2GRAY)
        ox = int(round(m['ext']['video_rect'][0] * ext.shape[1])); oy = int(round(m['ext']['video_rect'][1] * ext.shape[0]))
        fr = [read_rgb(f) for f in files]
        N = len(fr)
        As, inls = [], []
        for f in fr:
            A, n = sim_match(f, eg, ox, oy, w, h)
            As.append(A); inls.append(n)
        # 帧间链式跟踪(整帧 LK + RANSAC，人物当外点)：C[t] = 第 0 帧 -> 第 t 帧
        gs = [cv2.cvtColor(f, cv2.COLOR_RGB2GRAY) for f in fr]
        C = [np.eye(3)]
        for t in range(1, N):
            Mt, _ = pair_A(gs[t - 1], gs[t]); C.append(Mt @ C[-1])
        cand = [t for t in range(N) if As[t] is not None and inls[t] >= 20]
        print(c, '  直接配准可用帧', len(cand), '/', N)
        mats = np.zeros((N, 6))
        for t in range(N):
            preds, wts = [], []
            for g in cand:
                d = abs(g - t)
                Mt = As[g] @ C[g] @ np.linalg.inv(C[t])          # 第 t 帧 px -> ext 坐标 (经 g 帧的直接配准 + 链式)
                preds.append(Mt[:2].reshape(-1)); wts.append(inls[g] / (1.0 + d) ** 2)
            if not preds:
                preds = [As[g][:2].reshape(-1) for g in cand]; wts = [inls[g] for g in cand]
            P_ = np.array(preds); W_ = np.array(wts)
            for k in range(6):                                   # 加权中位数
                o = np.argsort(P_[:, k]); cw = np.cumsum(W_[o]); mats[t, k] = P_[o, k][np.searchsorted(cw, cw[-1] / 2)]
        mats = gaussian_filter1d(mats, 1.0, axis=0, mode='nearest')
        ok = [t in cand for t in range(N)]
        cam = []
        S = np.diag([1.0 / w, 1.0 / h, 1.0]); Si = np.diag([float(w), float(h), 1.0])
        txs, tys, scs = [], [], []
        for t in range(N):
            Me = np.vstack([mats[t].reshape(2, 3), [0, 0, 1]])
            Mf = np.array([[1, 0, -ox], [0, 1, -oy], [0, 0, 1]]) @ Me     # 帧 px -> 海报 px
            Mn = S @ Mf @ Si                                               # 帧 uv -> 海报 uv
            cam.append([Mn[0, 0], Mn[0, 1], Mn[1, 0], Mn[1, 1], Mn[0, 2], Mn[1, 2]])
            q = (Mf @ np.array([w / 2, h / 2, 1.0]))[:2] - np.array([w / 2, h / 2]); txs.append(q[0]); tys.append(q[1])
            scs.append(np.sqrt(abs(np.linalg.det(Mf[:2, :2]))))
        cam = np.array(cam).round(6)
        print(c, f'cam: 直接配准内点 min {min(inls)} 中位 {int(np.median(inls))}  可用 {len(cand)}/{N}  中心平移 x [{min(txs):.0f},{max(txs):.0f}] y [{min(tys):.0f},{max(tys):.0f}]  缩放 [{min(scs):.3f},{max(scs):.3f}]')
        # 每帧整体色调增益(视频自带曝光/白平衡漂移，静态 ext 要跟着)：把 ext 按 cam 变换后，和该帧左右边带比 RGB 均值
        gains = []
        for t in range(N):
            a_, b_, c_, d_, tx_, ty_ = cam[t]
            Mp = Si @ np.array([[a_, b_, tx_], [c_, d_, ty_], [0, 0, 1]]) @ S
            et = cv2.warpAffine(ext, (np.array([[1, 0, ox], [0, 1, oy], [0, 0, 1]]) @ Mp)[:2], (w, h), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE)
            bw = max(8, int(w * .06))
            sel = np.zeros((h, w), bool); sel[:, :bw] = True; sel[:, -bw:] = True
            fa = fr[t].astype(np.float32); ea = et.astype(np.float32)
            ok_ = sel & (np.abs(fa.mean(2) - ea.mean(2)) < 40)
            gains.append((fa[ok_].mean(0) / np.maximum(ea[ok_].mean(0), 1.0)) if ok_.sum() > 100 else np.ones(3))
        gains = np.clip(gaussian_filter1d(np.array(gains), 1.5, axis=0, mode='nearest'), 0.85, 1.15)
        print(c, '  ext 逐帧色调增益范围', gains.min(0).round(3), gains.max(0).round(3))
        meta_save(c, cam=cam.tolist(), cam_gain=gains.round(4).tolist(), cam_inliers=[int(x) for x in inls])


def cmd_check(args):
    """在循环段均匀 5 帧上验证 ext(按 cam 变换后) 与视频左右边带的对位误差；存 review/v2b_align_<id>.jpg"""
    for c in ids(args):
        m = meta_load(c)
        w, h = m['w'], m['h']
        files = sorted(glob.glob(W2(c, 'loop', 'f*.png')))
        ext = read_rgb(A2(c, 'ext.jpg'))
        ox = int(round(m['ext']['video_rect'][0] * ext.shape[1])); oy = int(round(m['ext']['video_rect'][1] * ext.shape[0]))
        cam = np.array(m['cam'])
        S = np.diag([1.0 / w, 1.0 / h, 1.0]); Si = np.diag([float(w), float(h), 1.0])
        sel = np.linspace(0, len(files) - 1, 5).round().astype(int)
        rows = []
        print(c, '对位检查(循环段均匀 5 帧；左右边带 ext 相对视频的残余偏移 dx,dy，像素)')
        for t in sel:
            fr = read_rgb(files[t])
            a, b, cc, d, tx, ty = cam[t]
            Mn = np.array([[a, b, tx], [cc, d, ty], [0, 0, 1]])
            Mp = Si @ Mn @ S
            Me = np.array([[1, 0, ox], [0, 1, oy], [0, 0, 1]]) @ Mp
            et = cv2.warpAffine(ext, Me[:2], (w, h), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE)
            res = []
            for xs in ((0, int(w * .22)), (int(w * .78), w)):
                ga = cv2.cvtColor(fr, cv2.COLOR_RGB2GRAY)[:, xs[0]:xs[1]].astype(np.float32)
                gb = cv2.cvtColor(et, cv2.COLOR_RGB2GRAY)[:, xs[0]:xs[1]].astype(np.float32)
                ga = ga - cv2.GaussianBlur(ga, (0, 0), 12); gb = gb - cv2.GaussianBlur(gb, (0, 0), 12)
                (dx, dy), r = cv2.phaseCorrelate(ga, gb, cv2.createHanningWindow(ga.shape[::-1], cv2.CV_32F))
                res.append((dx, dy))
            print(f'  帧 {t:3d}: 左 ({res[0][0]:+.1f},{res[0][1]:+.1f})  右 ({res[1][0]:+.1f},{res[1][1]:+.1f})')
            sw = int(w * .25)
            rows.append(np.concatenate([fr[:, :sw], et[:, :sw], fr[:, -sw:], et[:, -sw:]], 1))
        sheet = np.concatenate(rows, 0)
        sc = min(1.0, 1800 / sheet.shape[0], 1600 / sheet.shape[1])
        Image.fromarray(sheet).resize((int(sheet.shape[1] * sc), int(sheet.shape[0] * sc)), Image.LANCZOS).save(P('review', f'v2b_align_{c}.jpg'), quality=90)


def cmd_extra(args):
    for c in (args or list(EXTRA)):
        for f in (cmd_stab, cmd_loop, cmd_depth, cmd_pack, cmd_subject):
            f([c])


def cmd_all(args):
    for fn in (cmd_stab, cmd_loop, cmd_depth, cmd_pack, cmd_subject, cmd_ext, cmd_cam, cmd_check):
        fn(args)


if __name__ == '__main__':
    globals()['cmd_' + sys.argv[1]](sys.argv[2:])
