import subprocess, shutil, os, sys, glob, cv2, numpy as np
FF=r'E:\claude工作区\back-to-work-video\tools\ffmpeg.exe'
ROOT='assets2'; BAK='work6/bak_prefilter'
IDS=['road','street','lake','vegas','cloud','goldengate','glencanyon']
def rad(h):
    if h>=1080: return 13
    if h>=1000: return 11
    if h>=700: return 9
    if h>=400: return 5
    return 3
def chain(h):
    r=rad(h); c=5 if h>=700 else 3
    return f"unsharp=lx={r}:ly={r}:la=0.22:cx={c}:cy={c}:ca=0,cas=0.55,eq=gamma=1.09:brightness=0.008"
CURVES="curves=b='0/0.03 0.4/0.41 1/1':r='0/0 0.6/0.59 1/1'"
TO_RGB="scale=in_range=tv:in_color_matrix=bt709:flags=accurate_rnd+full_chroma_int,format=gbrp"
TO_YUV="scale=out_range=tv:out_color_matrix=bt709:flags=accurate_rnd+full_chroma_int,format=yuv420p"
def rgbh(name,H):
    if name=='live_s.mp4': return H
    if name=='live_card.mp4': return H*2//3
    return H//2
def run(cmd):
    r=subprocess.run(cmd,capture_output=True,text=True)
    if r.returncode: print(r.stderr[-1500:]); raise SystemExit(1)
def do_video(i,name):
    src=f'{ROOT}/{i}/{name}'; bak=f'{BAK}/{i}/{name}'
    os.makedirs(os.path.dirname(bak),exist_ok=True)
    if not os.path.exists(bak): shutil.copy2(src,bak)
    c=cv2.VideoCapture(bak); W=int(c.get(3)); H=int(c.get(4)); c.release()
    rh=rgbh(name,H); out=src+'.tmp.mp4'
    flt=f"crop={W}:{rh}:0:0,{chain(rh)},{TO_RGB},{CURVES},{TO_YUV}"
    if rh<H:
        fc=f"[0:v]split=2[a][b];[a]{flt}[c];[b]crop={W}:{H-rh}:0:{rh},format=yuv420p[d];[c][d]vstack=inputs=2,setparams=colorspace=bt709:color_primaries=bt709:color_trc=bt709:range=tv[o]"
    else:
        fc=f"[0:v]{flt},setparams=colorspace=bt709:color_primaries=bt709:color_trc=bt709:range=tv[o]"
    run([FF,'-y','-loglevel','error','-i',bak,'-filter_complex',fc,'-map','[o]','-an','-c:v','libx264','-preset','slow','-crf','16','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-color_range','tv','-movflags','+faststart',out])
    os.replace(out,src); print('video',i,name,W,H,'rgb',rh)
def do_still(i,name):
    src=f'{ROOT}/{i}/{name}'; bak=f'{BAK}/{i}/{name}'
    os.makedirs(os.path.dirname(bak),exist_ok=True)
    if not os.path.exists(bak): shutil.copy2(src,bak)
    h=cv2.imread(bak).shape[0]
    flt=f"{chain(h)},{TO_RGB},{CURVES},format=rgb24"
    run([FF,'-y','-loglevel','error','-i',bak,'-vf',flt,'-q:v','2',src]); print('still',i,name,h)
if __name__=='__main__':
    for i in IDS:
        for n in ['live.mp4','live_card.mp4','live_full.mp4','live_s.mp4']:
            if os.path.exists(f'{ROOT}/{i}/{n}'): do_video(i,n)
        for n in ['poster.jpg','ext.jpg']:
            if os.path.exists(f'{ROOT}/{i}/{n}'): do_still(i,n)
