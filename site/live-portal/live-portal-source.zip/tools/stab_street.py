# 街景：先稳定、再 0.5× 慢放
#  1) LK 特征 + RANSAC(人物是离群点)得到相邻帧的相似变换，累积成相机路径
#  2) 路径强低通(高斯 sigma=SIG 帧)，每帧变形到平滑路径上，再放大 ZOOM 裁掉黑边；深度那半幅用同一个变换
#  3) ext 跟踪(cam)按变换重写
#  4) 0.5× 慢放：RGB 用 minterpolate(mci)，深度用帧混合，与原来的慢放流程一致
import cv2, json, subprocess, sys
import numpy as np
sys.path.insert(0, 'work4')
from mkloop2 import gray, cam_through, FF
SIG = float(sys.argv[1]) if len(sys.argv) > 1 else 12.0
ZOOM = float(sys.argv[2]) if len(sys.argv) > 2 else 1.07
src = 'assets2/street/live_orig.mp4'
m = json.load(open('assets2/street/meta_orig.json'))
cap = cv2.VideoCapture(src); F = []
while True:
    ok, f = cap.read()
    if not ok: break
    F.append(f)
n = len(F); W = F[0].shape[1]; h = F[0].shape[0] // 2
G = [gray(f[:h], 0.5) for f in F]


def step(A, B):
    p0 = cv2.goodFeaturesToTrack(A, 600, 0.01, 8)
    p1, st, _ = cv2.calcOpticalFlowPyrLK(A, B, p0, None, winSize=(31, 31), maxLevel=4)
    ok = st.ravel() == 1
    M, inl = cv2.estimateAffinePartial2D(p0[ok], p1[ok], method=cv2.RANSAC, ransacReprojThreshold=1.5, maxIters=3000)
    M = M.copy(); M[:, 2] *= 2          # 0.5 尺度 → 全分辨率
    return M, float(inl.mean())


def to3(M): return np.vstack([M, [0, 0, 1]])


Ms = []; inls = []
for i in range(n - 1):
    M, q = step(G[i], G[i + 1]); Ms.append(to3(M)); inls.append(q)
C = [np.eye(3)]
for M in Ms: C.append(M @ C[-1])            # C_k：帧 0 坐标 → 帧 k 坐标


def params(T):                              # 相似变换 → (tx, ty, 角度, ln 缩放)
    a, b = T[0, 0], T[1, 0]
    return np.array([T[0, 2], T[1, 2], np.arctan2(b, a), np.log(np.hypot(a, b))])


def from_params(p):
    s = np.exp(p[3]); c, sn = np.cos(p[2]) * s, np.sin(p[2]) * s
    return np.array([[c, -sn, p[0]], [sn, c, p[1]], [0, 0, 1]])


P = np.array([params(T) for T in C])
k = int(SIG * 3); xs = np.arange(-k, k + 1); g = np.exp(-xs ** 2 / (2 * SIG ** 2)); g /= g.sum()
Pp = np.pad(P, ((k, k), (0, 0)), mode='reflect')
S = np.stack([np.convolve(Pp[:, j], g, mode='valid') for j in range(4)], 1)
Z = np.array([[ZOOM, 0, (1 - ZOOM) * W / 2], [0, ZOOM, (1 - ZOOM) * h / 2], [0, 0, 1]])
Ts = [Z @ from_params(S[i]) @ np.linalg.inv(C[i]) for i in range(n)]
# 报告：抖动
raw_step = np.array([np.hypot(*P[i + 1, :2] - P[i, :2]) for i in range(n - 1)])
sm_step = np.array([np.hypot(*S[i + 1, :2] - S[i, :2]) for i in range(n - 1)])
print('camera path step px: raw mean %.1f jitter(std of step) %.2f | smoothed mean %.1f jitter %.2f' % (raw_step.mean(), raw_step.std(), sm_step.mean(), sm_step.std()), 'inlier mean %.2f' % np.mean(inls))
cam = np.array(m['cam'], float)
newcam = []
out = []
for i in range(n):
    T = Ts[i][:2]
    top = cv2.warpAffine(F[i][:h], T, (W, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    bot = cv2.warpAffine(F[i][h:], T, (W, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    out.append(np.vstack([top, bot]))
    newcam.append([float(x) for x in cam_through(cam[i], T, W, h)])
p = subprocess.Popen([FF, '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', f'{W}x{2 * h}', '-r', '30', '-i', '-', '-an', '-c:v', 'libx264', '-crf', '12', '-preset', 'medium', '-pix_fmt', 'yuv420p', 'work5/street_stab.mp4'], stdin=subprocess.PIPE)
for f in out: p.stdin.write(f.tobytes())
p.stdin.close(); p.wait()
m2 = dict(m); m2['cam'] = newcam; json.dump(m2, open('work5/street_stab_meta.json', 'w'), indent=1)
# 0.5× 慢放
vf = ("[0:v]split=2[a][b];[a]crop=720:1280:0:0,minterpolate=fps=60:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1[r];"
      "[b]crop=720:1280:0:1280,framerate=fps=60:interp_start=0:interp_end=255:scene=100[d];[r][d]vstack,setpts=2*PTS,fps=30,format=yuv420p")
r = subprocess.run([FF, '-v', 'error', '-y', '-i', 'work5/street_stab.mp4', '-filter_complex', vf, '-an', '-c:v', 'libx264', '-crf', '14', '-preset', 'medium', 'work5/street_stab_slow.mp4'], capture_output=True, text=True)
print('slow', r.stderr[:200])
