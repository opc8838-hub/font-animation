# 方案 A 演示 v2：CDP 逐帧截取；intro → 首页扫过 → road / LA(只播一遍 b80→b189→切街景) / lake → 首页停 0.4s → outro → 末帧停
import asyncio, time, json, base64, os, shutil
from playwright.async_api import async_playwright
OUT = r'E:\claude工作区\jd-portal\out\frames_v4'
CLEAN_CSS = "#skip,#back,#load,#motion{display:none!important;opacity:0!important}"
W, H = 1920, 1080
async def main():
    shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
    async with async_playwright() as p:
        b = await p.chromium.launch(channel='msedge', headless=False, args=[
            '--autoplay-policy=no-user-gesture-required', '--disable-features=CalculateNativeWinOcclusion',
            '--disable-backgrounding-occluded-windows', '--disable-renderer-backgrounding', '--disable-background-timer-throttling',
            f'--window-size={W},{H + 140}', '--window-position=0,0'])
        ctx = await b.new_context(viewport={'width': W, 'height': H}, device_scale_factor=1)
        await ctx.add_init_script(f"document.addEventListener('DOMContentLoaded',()=>{{const s=document.createElement('style');s.textContent='{CLEAN_CSS}';document.head.appendChild(s);}});")
        pg = await ctx.new_page()
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        await pg.goto('http://localhost:8794/web2/index.html?intro=0', wait_until='load'); await pg.wait_for_timeout(5000)   # 预热缓存
        await pg.wait_for_function('window.__portal && window.__portal.cards.length==3', timeout=60000)
        for i in (0, 1, 2):                                          # 每张卡都打开一遍：卡片版/全屏版视频 + ext 图进浏览器缓存
            await pg.evaluate(f'window.__portal.openCard({i})'); await pg.wait_for_timeout(3500)
            await pg.evaluate('window.__portal.closeCard()'); await pg.wait_for_function('window.__portal.S.open < 0', timeout=10000); await pg.wait_for_timeout(500)
        await pg.wait_for_timeout(2000)
        cdp = await ctx.new_cdp_session(pg)
        frames = []
        def on_frame(ev):
            frames.append((ev['metadata']['timestamp'], ev['data']))
            asyncio.ensure_future(cdp.send('Page.screencastFrameAck', {'sessionId': ev['sessionId']}))
        cdp.on('Page.screencastFrame', on_frame)
        await pg.goto('http://localhost:8794/web2/index.html', wait_until='domcontentloaded')
        await cdp.send('Page.startScreencast', {'format': 'jpeg', 'quality': 92, 'maxWidth': W, 'maxHeight': H, 'everyNthFrame': 1})
        await pg.wait_for_function('window.__portal && window.__portal.I && window.__portal.I.on && window.__portal.I.t > 0', timeout=90000, polling=16)
        t_intro = time.time(); log = {'intro_wall': t_intro}
        await pg.wait_for_function('window.__portal && !window.__portal.I.on', timeout=30000, polling=16)
        # 开场刚结束：触发后台加载(ext/全屏视频/结尾素材)并等它们做完，这段静止首页的帧最后会被剪掉
        log['gap_start'] = time.time(); await pg.mouse.move(W * 0.1, H * 0.8); await asyncio.sleep(8.0); log['gap_end'] = time.time()
        P = await pg.evaluate("() => [0,1,2].map(i => { const r = window.__portal.homeRect(i); return [r.cx, r.cy]; })")
        async def glide(x0, y0, x1, y1, dur):
            t0 = time.time()
            while True:
                u = min(1, (time.time() - t0) / dur); e = u * u * (3 - 2 * u)
                await pg.mouse.move(x0 + (x1 - x0) * e, y0 + (y1 - y0) * e)
                if u >= 1: break
                await asyncio.sleep(0.012)
        async def hold(d): await asyncio.sleep(d)
        # ---- 首页：鼠标滑过三张卡(倾斜 + 悬停高光) ≈1s
        await pg.mouse.move(W * 0.1, H * 0.8)
        await hold(1.2)
        await glide(W * 0.1, H * 0.8, P[0][0], P[0][1], 0.4)
        await glide(P[0][0], P[0][1], P[2][0], P[2][1] - 30, 0.6)
        await glide(P[2][0], P[2][1] - 30, P[0][0], P[0][1] + 30, 0.35)
        prev = (P[0][0], P[0][1] + 30)
        for i in (0, 1, 2):
            cx, cy = P[i]
            if i == 1:                                                # LA：先把卡片版对齐到全屏版第 0 帧(镜头 2 开头 b61)，再点开
                await pg.evaluate("(()=>{const c=window.__portal.cards[1]; const j=c.meta.full.f2c[0]; c.cardVideo.currentTime=(j+0.5)/c.meta.fps;})()")
            await glide(prev[0], prev[1], cx, cy, 0.3)
            await pg.mouse.click(cx, cy)
            await hold(0.9)                                           # 放大
            if i == 2:                                                # 湖卡全屏遮住 LA 时：把 LA 卡片版拨回镜头 2 开头(b5)，并停住(暂停但让纹理刷新到该帧)
                await pg.evaluate("""async()=>{const c=window.__portal.cards[1],v=c.cardVideo; v.pause(); v.currentTime=0.02; await new Promise(r=>v.addEventListener('seeked',r,{once:true})); v.play(); await new Promise(r=>v.requestVideoFrameCallback(()=>r())); await new Promise(r=>v.requestVideoFrameCallback(()=>r())); v.pause(); v.currentTime=0.02; await new Promise(r=>v.addEventListener('seeked',r,{once:true})); return v.currentTime;}""")
            await glide(cx, cy, W * 0.5, H * 0.5, 0.15)
            if i == 1:                                                # LA：全屏版从镜头 2 开头播：慢动作倒着走 ~3s -> 甩镜 -> 街景 ~0.8s，播到第二次甩镜刚开始(全屏版 3.1s)就关闭
                await pg.wait_for_function("(()=>{const c=window.__portal.cards[1]; return c.video===c.fullVideo && c.fullVideo.currentTime>=3.12;})()", timeout=20000, polling=16)
                await glide(W * 0.5, H * 0.5, W * 0.52, H * 0.5, 0.3)
            else:                                                     # road / lake：一次平滑的左→右平移
                await glide(W * 0.5, H * 0.5, W * 0.54, H * 0.5, 0.1)
                await glide(W * 0.54, H * 0.5, W * 0.15, H * 0.5, 0.35)
                await glide(W * 0.15, H * 0.5, W * 0.85, H * 0.5, 1.6)
                await hold(0.75 if i == 0 else 0.25)                      # road 全屏多停 0.5s
            if i == 2:                                                # 鼠标先挪到下方(避免悬停高光)；告诉页面「LA 视频在播」，这样它不会在关闭动画开始时自己恢复播放，等关完再手动 play
                await glide(W * 0.85, H * 0.5, W * 0.5, H * 0.97, 0.25)
                await pg.evaluate("(()=>{window.__portal.cards[1].playing=true;})()")
            await pg.evaluate('window.__portal.closeCard()')
            await pg.wait_for_function('window.__portal.S.open < 0', timeout=10000, polling=16)
            await hold(0.1)
            prev = (W * 0.5, H * 0.5)
        await pg.evaluate("(()=>{const v=window.__portal.cards[1].cardVideo; v.play(); const t=setInterval(()=>{ if (v.currentTime>4.15) { v.pause(); clearInterval(t); } }, 8);})()")   # 结尾开始的同一时刻 LA 才从镜头 2 开头播(下一次甩镜在 4.3s 后，结尾 3.4s + 末帧 0.4s 以内碰不到)
        log['outro_wall'] = time.time()
        ok = await pg.evaluate('window.__portal.outro()'); log['outro_ok'] = ok
        await pg.wait_for_function('window.__portal.O.on && window.__portal.O.t >= 3.39', timeout=20000, polling=16)
        await hold(0.4)
        await cdp.send('Page.stopScreencast')
        log['end_wall'] = time.time(); log['n'] = len(frames); log['errors'] = errs[:10]
        meta = []
        for k, (ts, data) in enumerate(frames):
            fn = os.path.join(OUT, f'f{k:05d}.jpg'); open(fn, 'wb').write(base64.b64decode(data)); meta.append([ts, fn])
        json.dump({'log': log, 'frames': meta}, open(os.path.join(OUT, 'meta.json'), 'w'))
        ts = [m[0] for m in meta]; d = [b_ - a for a, b_ in zip(ts, ts[1:])]
        print('frames', len(ts), 'span', round(ts[-1] - ts[0], 2), 's', 'avg dt', round(sum(d) / len(d) * 1000, 1), 'ms', 'max dt', round(max(d) * 1000), 'ms', 'ok', ok, 'errors', errs[:5])
        await b.close()
asyncio.run(main())
