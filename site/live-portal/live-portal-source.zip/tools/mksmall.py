import json,subprocess
FF=r'E:\claude工作区\back-to-work-video\tools\ffmpeg.exe'
import sys
for d in (sys.argv[1:] or 'road street lake vegas cloud glencanyon goldengate'.split()):
    m=json.load(open(f'assets2/{d}/meta.json')); w,h=m['w'],m['h']; a,b,c,e=m['card_window']
    x0=round(a*w); y0=round(b*h); cw=round((c-a)*w); ch=round((e-b)*h)
    SW,SH=(240,320) if d in ("vegas","cloud","glencanyon","goldengate") else (360,480)
    vf=f"crop={cw}:{ch}:{x0}:{y0},scale={SW}:{SH}:flags=lanczos,format=yuv420p"
    r=subprocess.run([FF,'-v','error','-y','-stream_loop','3','-i',f'assets2/{d}/live.mp4','-vf',vf,'-an','-c:v','libx264','-crf','22','-preset','medium','-g','12','-movflags','+faststart',f'assets2/{d}/live_s.mp4'],capture_output=True,text=True)
    print(d,r.stderr[:100])
