# 流光赛道 / Prism Road

这个源码包包含展示页、WebGL2 引擎及 GLSL、For AI 描述和页面样式。要在本地重放定稿，请从同一版本的 CellMotion 站点或仓库复制以下资源，并保留目录结构。

1. 复制 `site/prism-road/assets/` 到解压目录下的 `prism-road/assets/`。完整的 24 项清单在 `effects/prism-road.component.json` 的 `inputs.groups` 中。
2. 复制 `site/prism-road/previews/prism-road-card.mp4` 到 `prism-road/previews/`，供视频回退使用。
3. 在解压目录运行 `python -m http.server 8000`，通过本地 HTTP 打开 `/prism-road.html`。使用整个 CellMotion 仓库时也可直接从 `site/` 起站。
4. 录制定时帧时打开 `/prism-road.html?capture`，等待 `window.__prism.ready`，设置舞台尺寸，再调用 `window.__prism.renderAt(秒数)` 并读取画布。正式页面按可见状态推进时间。

页头链接指向 CellMotion 官网的同级页面。源码下载按钮指向本 ZIP，可将它放回 `prism-road/prism-road-source.zip`。

Inspired by Pranav's Crestora footer design.
